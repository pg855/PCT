PANKAJ COLDRINK TRADERS - WHATSAPP ORDER UPDATE

Upload all files in this ZIP to the root of the GitHub repository (PCT), replacing existing files when asked:
- index.html
- manifest.webmanifest
- service-worker.js
- icon.svg

Keep GitHub Pages set to main branch and /(root).
Published website: https://pg855.github.io/PCT/

The order form opens a WhatsApp message to the business number supplied for this setup. The customer must press Send in WhatsApp. Orders are requests only; the shop must confirm stock, prices, delivery charge and acceptance.
