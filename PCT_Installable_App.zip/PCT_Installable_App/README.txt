PCT INSTALLABLE WEB APP

Upload every file in this folder to the ROOT of GitHub repository pg855/PCT, replacing the old index.html. Commit changes.

Then open https://pg855.github.io/PCT/ in Chrome on Android. Tap the three-dot menu and choose Install app (or Add to Home screen).

This is an installable PWA, not a Play Store APK. Internet is needed to send WhatsApp requests. Requests are not confirmed until the shop replies. The WhatsApp business number is the one previously supplied (+91 7905550651); get father's permission before publishing it.

IMPORTANT CATALOGUE NOTES:
- Bisleri case quantities shown are based on earlier information. Verify 250 ml pack count with the supplier before accepting orders.
- Local Water, Pepsi and Coca-Cola options are generic placeholders because exact stocked products/sizes were not confirmed. Update these to actual stock.
- Prices are not displayed; shop confirms current price, availability and delivery charges.
